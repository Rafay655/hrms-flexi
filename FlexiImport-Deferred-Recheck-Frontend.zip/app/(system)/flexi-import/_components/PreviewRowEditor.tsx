"use client";

import { useState } from "react";
import { useIsMutating, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { batchReviewMutationKey } from "./StudioBatchActions";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type Field = { field_key: string; label: string; type: string };
type Row = {
  row_number: number;
  raw_data: Record<string, unknown> | null;
  draft_corrections?: Record<string, string | null> | null;
  status: string;
  row_action?: string | null;
  validation_errors?: { field: string; message: string }[] | null;
  processing_error?: string | null;
  value_diff?: { key?: string; field?: string; field_key?: string; label?: string; old: unknown; new: unknown }[] | null;
};
type Status = {
  status: string;
  can_edit_preview: boolean;
  has_unvalidated_corrections?: boolean;
  preview_fields?: Field[];
  column_mapping?: Record<string, string>;
  total_rows: number;
  successful_rows: number;
  failed_rows: number;
  has_gaps: boolean;
  requires_approval: boolean;
  review_before_approval: boolean;
};

const PAGE_SIZE = 50;
const statusKey = (uuid: string) => ["flexi-import", "editable-preview", uuid];
const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");
function cellText(value: unknown): string {
  if (value == null) return "";
  return typeof value === "object" ? JSON.stringify(value) : String(value);
}

export function useBatchPreviewStatus(uuid: string | null) {
  return useQuery<Status>({
    queryKey: statusKey(uuid ?? ""),
    enabled: Boolean(uuid),
    queryFn: async () => (await api.get(`/flexi-import/batches/${uuid}/status`)).data.data,
    refetchInterval: (query) => ["uploaded", "validating", "approved", "processing", "pending_approval"].includes(query.state.data?.status ?? "") ? 2000 : false,
  });
}

export default function PreviewRowEditor({ uuid, batchStatus, totalRows, submitApproval = false }: {
  uuid: string; batchStatus?: string; totalRows?: number; submitApproval?: boolean;
}) {
  const client = useQueryClient();
  const [page, setPage] = useState(1);
  const [editing, setEditing] = useState<Row | null>(null);
  const [initial, setInitial] = useState<Record<string, string>>({});
  const [values, setValues] = useState<Record<string, string>>({});
  const [message, setMessage] = useState("");
  const [notice, setNotice] = useState("");
  const reviewBusy = useIsMutating({ mutationKey: batchReviewMutationKey(uuid) }) > 0;
  const status = useBatchPreviewStatus(uuid);
  const batch = status.data;
  const currentStatus = batch?.status ?? batchStatus;
  const rowCount = batch?.total_rows ?? totalRows ?? 0;
  const checking = currentStatus === "validating" || currentStatus === "uploaded";
  const fields = batch?.preview_fields ?? [];
  const mapping = batch?.column_mapping ?? {};
  const enabled = batch?.can_edit_preview === true;
  const needsRecheck = batch?.has_unvalidated_corrections === true;
  const rows = useQuery<Row[]>({
    queryKey: ["flexi-import", "spreadsheet-rows", uuid, page, currentStatus],
    enabled: !!currentStatus && !checking,
    queryFn: async () => {
      const payload = (await api.get(`/flexi-import/batches/${uuid}/rows`, { params: { page } })).data.data;
      return Array.isArray(payload) ? payload : payload?.data ?? [];
    },
  });
  const columns = Array.from(new Set(rows.data?.flatMap((row) => Object.keys(row.raw_data ?? {})) ?? []));
  const changed = Object.fromEntries(Object.entries(values).filter(([key, value]) => initial[key] !== value));

  function fieldForColumn(column: string) {
    return fields.find((field) => (mapping[column] ?? column) === field.field_key)
      ?? fields.find((field) => normalize(column) === normalize(field.label));
  }

  function startEdit(row: Row) {
    const raw = row.raw_data ?? {};
    const next = Object.fromEntries(fields.map((field) => {
      const header = Object.keys(raw).find((key) => fieldForColumn(key)?.field_key === field.field_key);
      const value = row.draft_corrections && Object.hasOwn(row.draft_corrections, field.field_key)
        ? row.draft_corrections[field.field_key]
        : header === undefined ? null : raw[header];
      return [field.field_key, cellText(value)];
    }));
    setInitial(next);
    setValues(next);
    setEditing(row);
    setMessage("");
  }

  const review = useMutation({
    mutationKey: batchReviewMutationKey(uuid),
    mutationFn: async (action: "save" | "recheck" | "submit"): Promise<{
      status: string; has_unvalidated_corrections?: boolean;
    }> => {
      if (action === "save") {
        if (!editing) throw new Error("No row is selected.");
        const response = await api.patch(`/flexi-import/batches/${uuid}/rows`, {
          revalidate: false,
          changes: [{ row_number: editing.row_number, fields: changed }],
        });
        return response.data.data;
      }
      const path = action === "recheck" ? "revalidate" : "process";
      await api.post(`/flexi-import/batches/${uuid}/${path}`);
      return { status: action === "recheck" ? "validating" : "pending_approval" };
    },
    onSuccess: (result, action) => {
      setEditing(null);
      client.setQueryData<Status>(statusKey(uuid), (old) => old && {
        ...old,
        status: result.status,
        can_edit_preview: result.status === "validation_complete" && old.can_edit_preview,
        has_unvalidated_corrections: result.has_unvalidated_corrections ?? old.has_unvalidated_corrections,
      });
      if (action === "save" && result.status === "validation_complete") {
        setNotice("Correction saved.");
      }
    },
    onError: (error) => {
      const data = (error as { response?: { data?: { message?: string; error?: { message?: string } } } }).response?.data;
      setMessage(data?.error?.message ?? data?.message ?? "The request failed. Please try again.");
    },
    onSettled: () => client.invalidateQueries({ queryKey: ["flexi-import"] }),
  });
  const saving = review.isPending;
  const busy = saving || reviewBusy;

  function run(action: "save" | "recheck" | "submit") {
    if (busy || client.isMutating({ mutationKey: batchReviewMutationKey(uuid) })) return;
    setMessage("");
    setNotice("");
    review.mutate(action);
  }

  return (
    <section className="space-y-3 rounded-xl border p-4" aria-label="Spreadsheet preview">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-semibold">Spreadsheet preview</h3>
        {enabled && <Button type="button" size="sm" variant={needsRecheck ? "default" : "outline"} disabled={busy || Boolean(editing)}
          onClick={() => run("recheck")}>Re-check batch</Button>}
      </div>
      {needsRecheck && <p role="status" className="text-sm text-muted-foreground">Saved corrections need a re-check. The results below are from the previous validation.</p>}
      {!editing && notice && <p role="status" className="text-sm">{notice}</p>}
      {!editing && message && <p role="alert" className="text-sm text-destructive">{message}</p>}
      {((status.isError && !batchStatus) || rows.isError) && <p role="alert" className="text-sm">Unable to load the preview. <Button size="sm" variant="link" onClick={() => void (rows.isError ? rows.refetch() : status.refetch())}>Retry</Button></p>}
      {checking ? <p role="status" className="text-sm">Checking the spreadsheet…</p>
        : status.isLoading || rows.isLoading ? <p role="status" className="text-sm">Loading rows…</p>
        : rows.data?.length ? (
          <div className="overflow-x-auto rounded-md border">
            <table className="w-full text-sm">
              <thead className="bg-muted text-left">
                <tr><th scope="col" className="p-2">Row</th>
                  {columns.map((column) => <th scope="col" className="min-w-32 p-2" key={column}>{fieldForColumn(column)?.label ?? column}</th>)}
                  <th scope="col" className="min-w-40 p-2">Status</th>
                  {enabled && <th scope="col" className="min-w-24 p-2">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y">
                {rows.data.map((row) => <tr key={row.row_number}>
                  <th scope="row" className="p-2 text-left align-top">{row.row_number}</th>
                  {columns.map((column) => {
                    const key = fieldForColumn(column)?.field_key;
                    const value = key && row.draft_corrections && Object.hasOwn(row.draft_corrections, key)
                      ? row.draft_corrections[key] : row.raw_data?.[column];
                    return <td className="whitespace-pre-wrap break-words p-2 align-top" key={column}>{cellText(value) || "—"}</td>;
                  })}
                  <td className="space-y-1 p-2 align-top">
                    <p className="capitalize">{(row.row_action ?? row.status).replaceAll("_", " ")}{row.row_action && row.status === "invalid" ? " · Invalid" : ""}</p>
                    {row.validation_errors?.map(({ field, message }, index) => <p key={index} className="text-xs text-destructive">{field}: {message}</p>)}
                    {row.processing_error && <p className="text-xs text-destructive">{row.processing_error}</p>}
                    {!!row.value_diff?.length && <details>
                      <summary className="cursor-pointer">Review changes</summary>
                      {row.value_diff.map((diff, index) => <p key={index} className="text-xs">{diff.label ?? diff.field ?? diff.field_key}: {cellText(diff.old) || "—"} → {cellText(diff.new) || "—"}</p>)}
                    </details>}
                  </td>
                  {enabled && <td className="p-2 align-top">{["valid", "invalid"].includes(row.status) && <Button
                    size="sm" variant="outline" disabled={busy || fields.length === 0}
                    aria-label={`Edit row ${row.row_number}`} onClick={() => startEdit(row)}>Edit row</Button>}</td>}
                </tr>)}
              </tbody>
            </table>
          </div>
        ) : !rows.isError && (!status.isError || batchStatus) ? <p className="text-sm text-muted-foreground">No rows to preview.</p> : null}
      {rowCount > PAGE_SIZE && <div className="flex items-center gap-3">
        <Button size="sm" variant="outline" disabled={page === 1 || rows.isFetching || busy || checking} onClick={() => setPage((value) => value - 1)}>Previous</Button>
        <span className="text-sm">Page {page}</span>
        <Button size="sm" variant="outline" disabled={page * PAGE_SIZE >= rowCount || rows.isFetching || busy || checking} onClick={() => setPage((value) => value + 1)}>Next</Button>
      </div>}
      {submitApproval && enabled && batch?.review_before_approval && batch.requires_approval && <Button
        disabled={busy || needsRecheck || Boolean(editing) || batch.successful_rows === 0 || batch.failed_rows > 0 || batch.has_gaps}
        onClick={() => run("submit")}>Submit for approval</Button>}
      <Dialog open={Boolean(editing) && enabled} onOpenChange={(open) => { if (!open && !saving) setEditing(null); }}>
        <DialogContent className="sm:max-w-2xl">
          <DialogHeader><DialogTitle>Edit row {editing?.row_number}</DialogTitle>
            <DialogDescription>Save your changes, then re-check once after editing all rows.</DialogDescription></DialogHeader>
          {message && <p role="alert" className="text-sm text-destructive">{message}</p>}
          <form className="space-y-4" onSubmit={(event) => {
            event.preventDefault();
            if (editing && Object.keys(changed).length) run("save");
          }}>
            <div className="grid max-h-[55vh] gap-3 overflow-y-auto p-1 sm:grid-cols-2">
              {fields.map((field) => <label key={field.field_key} className="space-y-1 text-sm">
                <span>{field.label}</span>
                <input className="w-full rounded-md border bg-background p-2" value={values[field.field_key] ?? ""}
                  disabled={saving} onChange={(event) => setValues({ ...values, [field.field_key]: event.target.value })} />
              </label>)}
            </div>
            <div className="flex gap-2">
              <Button type="submit" disabled={saving || Object.keys(changed).length === 0}>{saving ? "Saving…" : "Save correction"}</Button>
              <Button type="button" variant="outline" disabled={saving} onClick={() => setEditing(null)}>Cancel</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
}
